# Advanced HTML Server ON ESP32
![sadasd](img/TTGO-1.jpg)  
In this example we are trying to implement an advanced HTML server on our TTGO/LILYGO board to control two lamps (Red & Green).  

![sadasd](img/HTMLserver1.JPG)  

## Create your resource
You have to upload the files in the `HTML` folder as a resource in your project. The HTML file and images will download and save to SPIFFS (user area), after first time the MCU starts.  
![sadasd](img/htmlupld1.jpg)  
![sadasd](img/htmlupld2.jpg)  
