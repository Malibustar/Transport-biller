#include "barField.h"

using namespace Menu;

const char* barFieldOptions::fill="|";
const char* barFieldOptions::empty="-";
