# TTGO_T-CALL_NEO_6M_GPS_TRACKER
This repo contains code and details on TTGO T Call board and NEO 6M GPS Module with blynk based tracker which displays live location of Device on the App Via Internet.
Get your PCBs from : PCBgogo coupon: https://www.pcbgogo.com/thanks2021.html 
PCBgogo: https://www.pcbgogo.com/promo/from_electronic_GURU 
PCBgogo is the experienced quick-turn small-volume PCB prototype and turnkey PCB assembly manufacturer,
offering 12 &amp; 24 hours expedited PCB prototype service for PCB &amp; PCB assembly. 
PCBgogo fast PCB prototypes manufacturing and assembling is a good choice. 

